# Twitch Chat TTS

## Usage

Load index.html into your browser environment with access to internet and audio output.  

Enter the channel name in the text field and press enter or the `GO` button.  

TTS will start automatically as messages come in.  

## Caution!

This project has absolutely no protection against memory overflows due to spam or a fast chat.  
Use with caution.  

