fetch('http://localhost:8911/api/v2/commands')
    .then(response => response.json())
    .then(data => {
        if (!Array.isArray(data.Commands)) {
            throw new Error('La respuesta no contiene un array de comandos');
        }

        const comandos = data.Commands;
        const listaComandos = comandos.map(cmd => ({ name: cmd.Name, id: cmd.ID }));
        console.log(listaComandos);
    })
    .catch(error => {
        console.error('Error al obtener los comandos:', error);
    });